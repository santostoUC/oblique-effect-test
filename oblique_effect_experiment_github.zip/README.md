# Oblique Effect Classroom Experiment

## What this is
A standalone browser-based classroom demonstration of orientation-dependent visual resolution.

Students complete six randomized trials:
- Vertical × 2
- Horizontal × 2
- 45° oblique × 2

During each trial, the grating progressively becomes finer. Students press the response button (or SPACE) when they can no longer resolve the individual lines.

## Put it on GitHub Pages

1. Create a new GitHub repository, for example:
   `oblique-effect-experiment`

2. Upload `index.html` to the repository root.

3. In GitHub, open:
   Settings → Pages

4. Under "Build and deployment", select:
   Deploy from a branch

5. Select:
   Branch: `main`
   Folder: `/ (root)`

6. Save.

GitHub will give you a public URL similar to:
`https://YOUR-USERNAME.github.io/oblique-effect-experiment/`

## Important limitation
This version records each student's results only in the browser session. It does NOT automatically send the data to the instructor.

That is intentional for the first version so that you can test the psychophysics activity safely.

For a true class experiment, the next version should send anonymous trial data to a central Google Sheet / database and give you a downloadable class dataset.

## Classroom recommendation
Do not present the hypothesis before the experiment. Have students predict which orientation will produce the best acuity first, then reveal the group results afterward.

This is a teaching demonstration, not a clinical visual-acuity test.
